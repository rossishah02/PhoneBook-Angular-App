run npm install 
run npm install http-server
run npm start 