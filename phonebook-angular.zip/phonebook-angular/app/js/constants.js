'use strict';

var AppSettings = {
  appTitle: 'PhoneBook App',
  apiUrl: 'https://my-json-server.typicode.com/voramahavir/contacts-mock-response/contacts/'
};

module.exports = AppSettings;
