'use strict';

var gulp = require('gulp');

gulp.task('deploy', ['prod'], function() {

  // Any deployment logic should go here

});